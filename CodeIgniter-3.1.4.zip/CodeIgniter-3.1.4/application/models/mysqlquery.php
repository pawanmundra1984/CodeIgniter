<?php

class mysqlquery extends CI_Model{
	public function loginAdmin($data){
		$sql = "select * from admin where email = '".$data['email']."' and password = '".$data['password']."'";
		$query = $this->db->query($sql);
		return $query->result('array');
	}
	
	public function registerUser(){
		$sql = "select * from user";
		$query = $this->db->query($sql);
		return $query->result('array');
	}
	
	public function addProduct($data){
		$this->db->insert('product',$data);
		return $this->db->insert_id();
	}
	
	public function viewProduct(){
		$sql = "select * from product";
		$query = $this->db->query($sql);
		return $query->result('array');
	}
	
}