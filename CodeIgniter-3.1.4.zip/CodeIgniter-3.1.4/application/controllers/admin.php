<?php
class Admin extends CI_Controller{
	public function __Construct(){
		parent::__Construct();
	}
	
	public function index(){
		if(checkSession()){
			redirect('admin/viewUser');
		}
		$this->load->view('admin/login');
	}
	
	public function login(){
		if(checkSession()){
			redirect('admin/viewUser');
		}
		$viewData = array(); 
		$data = $this->input->post();
		$resultData = $this->mysqlquery->loginAdmin($data);
		if(count($resultData) > 0){
			$this->session->set_userdata('admin',$resultData);
			redirect('admin/viewUser');
		}else{
			$viewData['error'] = "Please enter correct credentials";
		}
		$this->load->view('admin/login',$viewData);
	}
	
	public function viewUser(){
		if(!checkSession()){
			redirect('admin/login');
		}
		$resultData = $this->mysqlquery->registerUser();
		$this->load->view('admin/viewUser',$viewData);
	}
	
	public function addProduct(){
		if(!checkSession()){
			redirect('admin/login');
		}
		$this->load->view('addProduct');
	}
	
	public function saveProduct(){
		if(!checkSession()){
			redirect('admin/login');
		}
		$viewData = array();
		$data = $this->input->post();
		if(isset($data['save'])){
			unset($data['save']);
			if(isset($_FILE['file']['error']) && ($_FILE['file']['error'] == 0)){
				$fileName = $_FILE['file']['name'];
				$filenameArray = array_reverse(explode('.',$fileName));
				$fileExe = $filenameArray[0];
				$fileName = time().rand().'.'.$fileExe;
				$config['file_name'] = $fileName;
				$config['upload_path'] = './uploads/';
				$config['allowed_types'] = 'gif|jpg|png';
				$config['max_size']	= '100';
				$config['max_width']  = '1024';
				$config['max_height']  = '76';
				$this->load->library('upload',$config);
				//$this->upload->initialize();
				if($this->upload->do_upload('file')){
					$data['upload_file'] = $fileName;
				}
			}
			$resultData = $this->mysqlquery->addProduct($data);
			if($resultData>0){
				$viewData['success'] = "Product add successfully";
			}else{
				$viewData['error'] = "Product not add successfully";
			}
		}
		$this->load->view('addProduct', $viewData);
	}
	
	public function logOut(){
		$this->session->unset_userdata('admin');
		redirect('admin/login');
	}	
	
}
