<?php
	function checkSession(){
		$CI =& get_instance();
		$CI->load->library('session'); 
		$userData = $CI->session->userdata('admin');
		if(empty($userData)){
			return false;
		}else{
			return true;
		}
	}
