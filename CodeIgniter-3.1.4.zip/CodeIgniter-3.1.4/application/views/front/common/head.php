<link rel="stylesheet" href="<?php echo base_url()?>assets/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" href="<?php echo base_url()?>assets/bootstrap/css/bootstrap-theme.min.css" />
<!--<link href="<?php echo base_url()?>assets/" />-->
<script src="<?php echo base_url()?>assets/jquery-3.2.1.min.js"> </script>
<script src="<?php echo base_url()?>assets/bootstrap/js/bootstrap.min.js"> </script>
<script src="<?php echo base_url()?>assets/moment.min.js"> </script>
<script src="<?php echo base_url()?>assets/underscore-min.js"> </script>
<script src="<?php echo base_url()?>assets/validate.js"> </script>